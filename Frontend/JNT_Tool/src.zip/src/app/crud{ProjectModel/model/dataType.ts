export interface projects{
    projectId: number,
    projectName:string,
    client:string,
    budget:number,
    startDate:Date,
    endDate:Date,
    country:string,
    status: string
}